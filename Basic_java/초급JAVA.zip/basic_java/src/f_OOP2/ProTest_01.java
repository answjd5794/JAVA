package f_OOP2;

import z_exam.ProTest_03;//패키지가 달라서 import됨

public class ProTest_01 extends ProTest_03 {
	public static void main(String[] args) {
		//클래스와 생성자는 기본적으로 같이 간다고 생각하면 된다.
		//public class면 생성자도 public이 붙어야 한다.
		ProTest_02 pt2 = new ProTest_02();
		ProTest_03 pt3 = new ProTest_03();
		
		ProTest_01 pt1 = new ProTest_01();
//		pt1.
		
	}
	
}
