package f_OOP2;

public class InnerTest {
	public static void main(String[] args) {
		Outer out = new Outer();
		Outer.Inner in = out.new Inner();
		in.method2(50);
		
	}
}

class Outer{
	int value = 10;
	//내부클래스는 사실상 볼일이 거의 없다.
	class Inner{//인스턴스 클래스
		int value = 20;
		
		void method2(int value){
			System.out.println(value); // 넘어온 인자값
			System.out.println(this.value); // class Inner 기준 인자값 20
			System.out.println(Outer.this.value); // outer 클래스에 있는 인스턴스 value 호출
		}
	}
	
	static class Inner2{//static 클래스
		
	}
	
	void method(){
		class Inner3{//지역 클래스
			
		}
	}
}