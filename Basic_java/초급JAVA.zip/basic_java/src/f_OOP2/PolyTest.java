package f_OOP2;

public class PolyTest {
	public static void main(String[] args) {
		//1. SmartTv 3대를 저장해주세요
		SmartTv stv1 = new SmartTv();
		SmartTv stv2 = new SmartTv();
		SmartTv stv3 = new SmartTv();	
		
		SmartTv[] smartTv = {stv1,stv2,stv3};
		
		//2. AfreecaTv 3대를 저장해주세요
//		AfreecaTv[] afreecaTv = new AfreecaTv[3];
//		afreecaTv[0] = new AfreecaTv();
//		afreecaTv[1] = new AfreecaTv();
//		afreecaTv[2] = new AfreecaTv();
		
		AfreecaTv at1 = new AfreecaTv();
		AfreecaTv at2 = new AfreecaTv();
		AfreecaTv at3 = new AfreecaTv();
		
		AfreecaTv[] afreecaTv = {at1,at2,at3};
		
		//3. DMBtv 3대를 저장해주세요.
//		DMBtv[] dmbtv = new DMBtv[3];
//		dmbtv[0] = new DMBtv(); 
//		dmbtv[1] = new DMBtv(); 
//		dmbtv[2] = new DMBtv(); 
		
		DMBtv dtv1 = new DMBtv();
		DMBtv dtv2 = new DMBtv();
		DMBtv[] dtv = {dtv1,dtv2};
		
		Tv[] t = new Tv[]{stv1,stv2,stv3,at1,at2,at3,dtv1,dtv2};
		t[2] = (Tv)stv3;//upcating

		Tv t2 = t[3];
		
		SmartTv st2 = (SmartTv)t2;//down-casting
//		st2.internet();		
		SmartTv tt = (SmartTv)new Tv();
		//upcating 했다가 downcating은 가능하지만, downcating만은 불가능하다.
		
	}
}



class Tv {
	String color;
	int volume;

	void changeColor(){
		this.color = color;
	}
}

class SmartTv extends Tv {
	void internet(){
		
	}
}

class AfreecaTv extends Tv{
	void starBallon(){
		
	}
	
}

class DMBtv extends Tv{
	void antena(){
		
	}
	
}