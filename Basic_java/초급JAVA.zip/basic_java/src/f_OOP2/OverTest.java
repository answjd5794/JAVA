package f_OOP2;

public class OverTest {
	public static void main(String[] args) {
		OverGo og = new OverGo();
		String result = og.overMethod();
		System.out.println(result);
		
		System.out.println(og.value);
		//10
		int result2 = og.getOverUpValue();
		System.out.println(result2);
		
	}
}

class OverUp{
	int value = 10;
	
	String overMethod(){
		return "OverUp Method";
	}
	
}

class OverGo extends OverUp{
	int value = 20;
	
	@Override
	String overMethod(){
		return "OverGo Method";
		
	}
	
	String overMethod(int k){
		return k+"OverGO method";
		
	}
	
	int getOverUpValue(){
		return super.value;//super. >자식의 인스턴스 변수와 부모의 인스턴스 변수를 구분함
							//부모에 있는 인스턴스 변수에 접근하기 위해 사용됨
		
	}
}
	
