package f_OOP2;

import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnnoInner2 {
	public static void main(String[] args) {
		
		Button b1 =  new Button();
		
		b1.addActionListener(new ActionListener() {
//		b1.addActionListener(new ActionListener() (class EventHandler) {
			//객체 생성과 동시에 필요한 메서드까지 오버라이드 한번에 처리하는 것.
			//EventHandler라는 클래스는 없는데 객체를 생성
			//하지만 이름이 없어서 익명 클래스, 1회용
			//
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("1번 버튼 눌림");
			}
		});
	}
}
