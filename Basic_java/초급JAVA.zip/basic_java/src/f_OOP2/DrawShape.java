package f_OOP2;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;

public class DrawShape extends Frame{
	public static void main(String[] args) {
		DrawShape ds = new DrawShape();
		//ds.paint(g);
	}
	//기본 생성자
	DrawShape(){
		super("문정아 화이팅..");	//내 부모의 생성자를 호출하는 함수
								 	//문구의 title을 주었음 f2눌러서 확인 가능
		setSize(500, 500);			//값을 변경하거나 셋팅할 때 사용함		
		setBackground(Color.MAGENTA);//배경색바꾸는함수
		setVisible(true);			//보이게하는함수
		setResizable(false);		//옮겨다니는 화면 고정여부
		
		//원래는 callstack에 쌓이고 사라짐
		
	}
	

@Override
public void paint(Graphics g){
	//1. 매개변수가 두개인 생성자를 이용하여 Circle 객체를 만들어주세요.
	Circle c = new Circle(50, new Point(100,100));
	
	//2.g.drawOval() 원을 그려주세요.
	g.drawOval(c.center.x ,c.center.y, c.r*2 , c.r*2);
//	g.drawOval(x, y, width, height);
	//참조변수는 참조할 수 있어서 또 참조가 가능하다. 
	//참조변수 c의 center를 또 참조하는 변수 x
	
	//3. 매개변수가 하나인 생성자를 이용하여 Triangle객체를 만들어주세요.
	//100,100 200,200 200,100
	
	//	int[] a = new int[10];
	//참조변수는 주소값을 가진다.
	// int형 인 애들을 담는 배열의 주소값을 가지는 변수 a선언
	// = 
	// 그 int형10짜리 방을 할당.
	
	Triangle t = new Triangle(new Point[3]);
	 
	t.p[0] = new Point(100,100);
	t.p[1] = new Point(200,200);
	t.p[2] = new Point(200,100);
	
	
	
	//4.g.drawLine() 3개를 이용하여 삼각형을 그려주세요.
	g.drawLine(t.p[0].x, t.p[0].y, t.p[1].x, t.p[1].y);
	g.drawLine(t.p[1].x, t.p[1].y, t.p[2].x, t.p[2].y);
	g.drawLine(t.p[2].x, t.p[2].y, t.p[0].x, t.p[0].y);
	
	}
	
}

/**
 * 점을 관리하기 위한 클래스
 * @author PC-NEW13
 * @since 2020.08.24
 */


class Point{
	int x; //점의 x값
	int y; //점의 y값
	
	//매개변수 2개짜리 생성자
	Point(int x, int y){
		this.x = x;
		this.y = y;
		
	}
	
	
}


class Circle{
	//1. 반지름을(정수)값을 저장할 수 있는 변수 r을 선언해주세요.
	int r;
	
	//2. 점 하나를 저장할 수 있는 변수 center를 선언해주세요.
	Point center;
	
	//3. 매개변수가 두 개인 생성자를 이용하여 r과 center를 초기화해주세요.
	Circle(int r, Point center){
		this.r = r;
		this.center = center;
	}

	//4. 기본 생성자를 만들어주세요.
	//	단, 매개변수가 두 개인 생성자를 호출하여 좌표는 100,100 반지름은 50으로 초기화 해주세요.
	Circle(){
//		Point p = new Point(100,100);
		this(50,new Point(100,100));
	}
	
	
}

class Triangle{
	//1.  점 3개를 저장할 수 있는 변수 p를 선언
	Point[] p;
	
	//2. 매개변수가 하나있는 생성자를 만드시오.
	Triangle(Point[] p){
		this.p = p;
	}
	//3. 매개변수가 3개인 생성자를 만드시오.
	Triangle(Point x, Point y, Point z){
		p = new Point[3];
		p[0] = x;
		p[1] = y;
		p[2] = z;
	}
}
