package f_OOP2;

import java.util.Vector;


public class ProductTest {
	public static void main(String[] args) {
		NoteBook notebook = new NoteBook("MSI", 300);
		Styler styler = new Styler("LG", 200);
		Refrigerator ref = new Refrigerator("SAMSUNG", 500);
		
		Buyer b = new Buyer("화이트쨩", 1000);
//		Buyer b1 = new Buyer("강문정", 10000);
		
		b.buy(ref);
		b.buy(notebook);
		b.buy(notebook);
//		b1.summary("강문정");
//		b.refund("화이트쨩");
	}

}

class Product{
	String name; // 제품명
	int price; // 가격
	int mileage; // 마일리지;
	
	public Product(String name, int price){
		this.name = name;
		this.price = price;
		mileage = price/10;
	}
}

class NoteBook extends Product{ 

	NoteBook(String name, int price) {
		super(name, price);
	}

	@Override
	public String toString() {
		return "노트북";
	}

}

class Styler extends Product{
	public Styler(String name, int price) {
		super(name, price);
	}

	@Override
	public String toString() {
		return "스타일러";
	}
}

class Refrigerator extends Product{
	public Refrigerator(String name, int price){
		super(name, price);
	}

	@Override
	public String toString() {
		return "냉장고";
	}
}



class Buyer{
	String name;
	int money;
	int mileage;
	
	
	//10개를 담을 수있는 배열이 생성된 것과 같다.
	Vector item = new Vector();
	
	
	public Buyer(String name, int money){
		this.name = name;
		this.money = money;
	}
	
	void buy(Product nb){
		if(money < nb.price){
			System.out.println("돈 더 들고와");
			return;
		}else{
		money -= nb.price;
		mileage += nb.mileage;
		item.add(nb);//object로 upcasting해서 올라간거여서 나중에 꺼낼 때는 downcasting해서 써야 한다.
		System.out.println(name+" 고객님 "+ nb + "를 구매해주셔서 감사합니다.");
		//tostring 메서드가 오버라이딩 되어있으므로 nb를 찍어도 주소가 아닌 노트북이 출력이 됨.
		
		}
			
	}
//Buyer 클래스에 메서드를 생성함.
//1. summary
/*
				영 수 증
	구매목록
			NoteBook 	300만원
			Styler	 	200만원
			총합			500만원
			
	XXX의 고객님의 남은 돈은 XXX이고 마일리지는 XXX입니다.
	오늘도 좋은 하루 보내세요. 호갱님~! 		
 */
	
	
//1. summary 영수증 
	int sum = 0;//총합변수
	void summary(String name){
		System.out.println("==========================================");
		System.out.println("\t\t영   수   증\t\t");
		System.out.println("구매 목록");
	//item 배열의 
		for(int i=0; i < item.size(); i++){
			System.out.print("\t"+item.get(i));
			System.out.println("\t"+(( Product)item.get(i)).price+"만원");
			sum +=  ((Product)item.get(i)).price;
	//가격?????
	}
//	sum += i
		System.out.println("\t총   합\t" + sum+"만원");
		System.out.println(name + "고객님의 남은 돈은" + money + "이고 마일리지는 " + mileage + "입니다");
		System.out.println("오늘도 좋은 하루 보내세요. 호갱님~!"); 		
		System.out.println("==========================================");
		
	}

//2. refund 반품
/*
	1. 고려사항
	 - 물건을 산 내역이 없으면 굳이 반품하지 않아도 된다.
	 - 내가 산 물건만 반품이 가능하다.
	 - 반품했을 때는 마일리지, 돈, item 모두 복원해야한다.
 */

	void refund(Product nb){
	//이름을 받아서(String name)-> 구매한 내역(Vector 배열에 저장된 구매물품)을 조회-> 구매한 내역(배열의 size가 0이 아니면) 있으면 반품	
		for(int i=0; i < item.size(); i++){
			if(item.size() != 0){
			//	1) 돈 복구
			money += ((Product)item.get(i)).price;
			//	2) item 복구
//			item.;
			//	3) 마일리지 복구
			mileage -= ((Product)item.get(i)).mileage;
		}else{
			System.out.println("반품 목록이 없습니다.");
		}
		
		
	}
		System.out.println("\t\t반 품 내 역\t\t");
		System.out.println(name + "의 돈은 " + money + " 만원 입니다.");
		System.out.println(name + "의 구매내역은 " + item + "입니다.");
		System.out.println(name + "의 마일리지는 " + mileage + " 입니다.");
		
	
	}	


}
	

//새로운 클래스를 다 뜯어 고쳐야 함.
//3. 물품의 수량을 관리
/*
	- 몇 대를 샀는지, 앞에 샀던 내역에서 해당 내역을 찾아서 갯수를 바꾸고 없으면 추가를 해야 한다.
*/



//4. 고객의 목록을 관리
/*
	- 고객을 등록하고, 누가 뭐를 몇개를 샀는 지 누가 뭐를 반품했는지 알 수 있는 고객들을 관리할 수 있게 만들어야 한다.
*/