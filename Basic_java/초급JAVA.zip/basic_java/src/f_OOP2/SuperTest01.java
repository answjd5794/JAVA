package f_OOP2;

public class SuperTest01 {
	public static void main(String[] args) {
		
		
	}
}

class Parent2{
	int value = 40;
	void method(){
		System.out.println("Parent2");

	}
}
// 아무관계도 없음 오버라이딩, 오버로딩 x
class Child2 extends Parent2{
	//	int value = 30;
	//지역 확인->전역 확인->부모 확인
	//지역변수가 있는지 없는지 확인해야됨	
	void Method(){
		System.out.println(value);//매개변수가 없으면 지역변수가 없어서 30됨
		System.out.println(this.value);//30
		System.out.println(super.value);//40
		super.method(); //부모의 메서드도 호출이 가능하다.
	}
}