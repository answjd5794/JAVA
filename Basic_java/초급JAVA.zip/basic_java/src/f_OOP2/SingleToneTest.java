package f_OOP2;

public class SingleToneTest {
	public static void main(String[] args) {
		SingleTone s1 = SingleTone.getInstance();//public이면 가지고 올 수 있음
		//객체는 무조건 한번만 만들어짐
		SingleTone s2 = SingleTone.getInstance();//
		
	}
}
//상속하는 부모가되면 오류가난다. 부를수 없기 때문에 상속이 불가능하다. 이땐 final을 붙여준다.
final class SingleTone{
	private static SingleTone s; //전역 변수 생성
	
	private SingleTone(){
	
	}

	 static SingleTone getInstance(){
		if(s == null){
			s = new SingleTone();
		}
		
		return s;
	}
}