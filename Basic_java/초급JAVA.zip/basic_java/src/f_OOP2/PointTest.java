package f_OOP2;

public class PointTest {
	public static void main(String[] args) {
		
	}
}

class Point2{
	int x;
	int y;
	Point2(int x, int y){
		this.x = x;
		this.y = y;
	}
}

class Point3D extends Point2{
	int z;
	Point3D(int x, int y, int z){
		super(x,y); //this()와 같이 쓸 수 없음 
		this.z =z;
	}
	
	Point3D(){
		super(3, 5);
		//this를 타고 가면 super()를 호출함
	}
	
}