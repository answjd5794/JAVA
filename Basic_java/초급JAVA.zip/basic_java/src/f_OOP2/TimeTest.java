package f_OOP2;

public class TimeTest {
	public static void main(String[] args) {
		TimeVO t = new TimeVO();//TimeVO의 객체 생성
		
		//사용자가 10시간 입력(0-23)
		t.setHour(40);
		t.setMinute(200);
		t.setSecond(10000);

		//셋팅값을 가져오는 메서드를 반환값이 있으니까 변수하나에 담아서 출력해준다.
		int hour = t.getHour();
		int minute = t.getMinute();
		int second = t.getSecond();
		System.out.println(hour + " 시" + minute + " 분" + second + " 초");
	
		
		//시간 40시간 ->16시
		//분 200분 -> 19:20
		//초 10000초 -> 22:06:40
		
		//시간 22시간 ->22시
		//100분-> 23: 40
		//1000초-> 2:26:40
	}
}

class TimeVO{
	private int hour;//시
	private int minute;//분
	private int second;//초
	
	//시간을 셋팅하기 위한 메서드
	void setHour(int hour){
		if(hour > 23){
			this.hour = hour%24;
			
		}else{
			this.hour = hour;
		}
	}
	
	int getHour(){
		return hour;
	}
	
	//분을 셋팅하기 위한 메서드
	void setMinute(int minute){
		if(minute > 59){
			hour += minute/60;
			this.minute = minute%60;
			setHour(hour);
		}else{
			this.minute = minute;
		}
	}
	
	int getMinute(){
		return minute;
	}	
	
	//초를 셋팅하기 위한 메서드
	void setSecond(int second){
		if(second > 59){
		//60초부터는 나눠주고 넘어갔을 때 60 초에서 뺀 만큼을 냅두고 분만큼 올려줘야 한다.
			minute += second/60;
			this.second = second%60;
			setMinute(minute);
		}else{
			this.second = second;
		}
	}
	int getSecond(){
		return second;
		
	}
	
	
	
	
	
}