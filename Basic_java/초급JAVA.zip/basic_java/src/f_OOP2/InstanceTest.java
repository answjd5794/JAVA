package f_OOP2;

public class InstanceTest {
	public static void main(String[] args) {
		Object fc = new FireCar();
		
		if(fc instanceof FireCar){
			System.out.println("fc는 firecar의 인스턴스이다.");
			FireCar ff = (FireCar)fc;//형변환이 가능하다.
			
		}if(fc instanceof Car){
			System.out.println("fc는 Car의 인스턴스이다.");
			Car cc = (Car)fc;
			
		}if(fc instanceof Object){
			System.out.println("fc는 Object의 인스턴스이다.");
			Object ob = fc;//같은 타입이라 형변환 필요없음
		}
		
		Car c = new  Car();
		
		if(c instanceof FireCar){
			System.out.println("c는 firecar의 인스턴스이다.");
			FireCar ff = (FireCar)c;
			
		}
		Car cc = new FireCar();
		System.out.println(cc.a);
		System.out.println(cc.b);
		cc.method();
		cc.method2();
		
	}
}

class Car{
	static int a =20;
	int  b = 30;
	
	static void method(){
		System.out.println("Car 클래스 메서드");
	}
	void method2(){
		System.out.println("Car 인스턴스 메서드");
	}
	
}

class FireCar extends Car{
	static void method(){
		System.out.println("FireCar 클래스 메서드");
	}
	//만들어 놓은걸로 가져옴
	//인스턴스 메서드만 객체타입의 영향을 받음-> 참조변수 타입에 영향을 받지 않는다.
	//나머지는 참조변수의 타입에 영향을 받는다.
	@Override
	void method2(){
		System.out.println("FireCar 인스턴스 메서드");
	}
}



class Ambulance extends Car{}