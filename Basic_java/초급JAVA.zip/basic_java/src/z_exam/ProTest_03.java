package z_exam;

public class ProTest_03 {
	public int a =10;
	protected int b= 20;
	int c = 30; //디폴트
	private int d = 40;
	
}
