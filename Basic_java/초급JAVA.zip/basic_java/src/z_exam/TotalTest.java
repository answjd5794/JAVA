package z_exam;

public class TotalTest {//클래스 TotalTest가 Method Area에 생성된다. 이때 클래스 변수와 클래스 메서드가 같이 생성되는데 클래스 변수는 없고 클래스 메서드는 main()이다.
	public static void main(String[] args) {
		//클래스 메서드 main()가 호출되면 call stack에 쌓인다.
		TvMaker.color = "Blue"; //대입 연산자에 따라 왼쪽부터 TvMaker 클래스가 호출되면 이때 MethodArea의 TvMaker를 로드 한 후, 클래스 변수 String color를 찾는다.
		//이때 클래스 변수 String color는 선언만 되고 다른 값으로 초기화시키지 않았음으로 기본값인 null을 가지고 있는 상태이다.
		// 때문에 = "blue" 에 의해   null값을 지워주고 Blue로 초기화 시킨다.
		TvMaker tm = new TvMaker();
		//new TvMaker(); 부분에서 인스턴스를 생성해주면 main()안에 인스턴스를 생성해줬기 때문에 callstack main()안에 tm이 생성된다.
		//인스턴스 화를 통해 참조변수 tm이 생성되었고  이때 인스턴스 생성을 담당하는 heap 메모리에 tm의 주소가 생성된다.
		//tm은 인스턴스 변수는 String name = "", int age이며 인스턴스 메소드는 TvMaker(),TvMaker(String name, int age) 이고 따로 초기화가 되지 않았기 때문에 각각 변수타입에 맞춰 기본값으로 초기화 되어 heap안에 생성된다.
		tm.age = 30; 
		//main()에 생성된 참조변수 tm의 주소값을 찾기 위해 heap영역으로 가보면 int age = 0;으로 기본값으로 설정되어 있다.
		//이를 대입연산자에 의해 int age = 30;으로 초기화 해준다.
		// 3. 메서드 호출
		// 3.1
		System.out.println(TvControll.channel);
		//MethodArea Tv.Controll 클래스를 로드하여 클래스변수 channel을 찾아 설정되어있는 int channel = 15값을 불러와 console에 출력한다.
		TvControll.volumeDown();
		//MethodArea TvControll 클래스를 로드하여 클래스 메서드 volumeDown()을 찾아 실행하여 console창에 출력한다.
		//이때 voulumeDown()메서드는 클래스 메서드이며 반환타입은 int 메서드명은 volumeDown이고 매개변수는 없는 클래스 메서드이다.
		//volumeDown()메서드는 int channel == MAX_CHANNEL이면 channel++이므로 int channel = 15;이기 때문에 channel++해서  int channel=16;으로 초기화 횐다.
		System.out.println(TvControll.channel);
		//MethodArea Tv.Controll 클래스를 로드하여 클래스변수 channel을 찾아 int channel = 16값을 불러와 console에 출력한다.
		// 3.2
		TvControll tc; //TvControll 클래스의 참조변수 tc를 생성한다. 
		tc = new TvControll(); //대입연산자에 의해 new TvControll()을 통해 생성된 인스턴스를 참조변수 tc에 초기화한다.
		//이때 call stack main()부분에  참조변수 tc가 생성되고 heap에 tc의 주소가 생성된다.인스턴스 변수 int volumeUp(), 인스턴스 메서드가 int int volume = 100;이 생성된다.
		System.out.println(tc.volume);
		//tc.을 통해 heap에 생성된 인스턴스 변수 volume을 로드하여 \
		tc.volumeUp();
		System.out.println(tc.volume);
		tc.volumeUp();
		System.out.println(tc.volume);

		//
		Calc cc = new Calc();
		System.out.println(cc.add(Integer.MAX_VALUE, 4));
		System.out.println(cc.add(3L, Integer.MAX_VALUE));

	}
}

class TvMaker {
	// 1. 클래스 TvMaker가 Method Area에 생성된다. 이때 같이 생성되는 클래스 변수는 String color,int inch가 있고 클래스 메서드는 존재하지 않는다.
	// 1.1
	static String color;
	static int inch;
	// 1.2 클래스 TvMaker 안의 인스턴스 변수는 String name = "", int age이며 인스턴스 메소드는 TvMaker(),TvMaker(String name, int age)가 있다.
	//인스턴스 메서드와 변수는 인스턴스화를 해서 인스턴스가 생성될 때 heap에 쌓이기 때문에 Method Area에 같이 생성되지 않는다.
	
	String name = "";
	int age;

	// 2.TvMaker 클래스의 인스턴스 변수인 TvMaker()와 TvMaker(String name,int age)는 메소드 오버로딩에 따라서 
	// 2.1 
	TvMaker() {
		this("man", 25);
	}

	// 2.2
	TvMaker(String name, int age) {
		this.name = name;
		this.age = age;
	}
}

class TvControll { //클래스 TvControll이 Method Area에 생성된다. 이때 같이 생성되는 클래스 변수는 final int MAX_CHANNEL = 50,final int MIN_CHANNEL = 1,int channel = 15 가 있고
	//클래스 메서드는 int volumeDown()이 있다 
	final int MAX_VOLUME = 100;
	final int MIN_VOLUME = 0;
	static final int MAX_CHANNEL = 50;
	static final int MIN_CHANNEL = 1;

	static int channel = 15;
	int volume = 99;

	// 4. return문
	int volumeUp() {//인스턴스 메서드 이며 반환타입은 int 메서드명은 volumeUp이고 매개변수가 없는 인스턴스 메서드이다.
		if (volume == MAX_VOLUME) {
			volume = MIN_VOLUME;
		} else {
			volume++;
		}

		return volume;
	}

	static int volumeDown() {//클래스 메서드이며 반환타입은 int 메서드명은 volumeDown이고 매개변수는 없는 클래스 메서드이다.
		if (channel == MAX_CHANNEL) {
			channel = MIN_CHANNEL;
		} else {
			channel++;
		}
		return channel;
	}
}

class Calc { //클래스 Calc이 Method Area에 생성된다. 이때 같이 생성되는 클래스 변수와 메서드는 존재하지 않는다.
	// 5.
	int add(int a, int b) {
		return a + b;
	}

	long add(long a, int b) {
		return a + b;
	}

	int minus(int a, int b) {
		return a + b;
	}
}