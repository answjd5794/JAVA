package z_exam;

public class Exam_04 {
   public static void main(String[] args) {
//      1[5-1] 다음은 배열을 선언하거나 초기화한 것이다. 잘못된 것을 고르고 그 이유를 설명하시오.
//         int[] arr[];
//         int[] arr2 = {1,2,3,};
//         int[] arr3 = new int[5];
//         int[] arr4 = new int[5]{1,2,3,4,5};
//         //초기화 할 때 방 안에 값을 바로 넣어주는 것이기 떄문에 안됨
//         int arr5[5];
//         //
//         int[] arr6[] = new int[3][];
       
//      1[5-2] 다음과 같은 배열이 있을 때, 
//         arr.length =>  행의 길이
//         arr[0].length => 0번째 행의 배열에 저장된 요소의 수량
//        (1) arr[3].length의 값은 얼마인가?
//         4
//        (2) arr.length의 값은 얼마인가?
//         4
//        (3) System.out.println(arr[4][1])의 출력 결과는 얼마인가?
//         30
//      int[][] arr = {
//              { 5, 5, 5, 5, 5},
//              { 10, 10, 10},
//              { 20, 20, 20, 20},
//              { 30, 30}
//            };
//
//
//      2[5-3] 배열 arr에 담긴 모든 값을 더하는 프로그램을 완성하시오.

//          int[] arr = {10, 20, 30, 40, 50};
//          int sum = 0;
//         for(int i=0; i<arr.length;i++){
//               sum += arr[i];
//            }
//         System.out.print("arr에 담긴 합 = "+sum);
//         
//     
      


//      3[5-4] 2차원 배열 arr에 담긴 모든 값의 총합과 평균을 구하는 프로그램을 완성하시오.
      
//          int[][] arr = {
//                       { 5, 8, 13, 5, 2 },
//                       { 22, 13, 28 },
//                       { 2, 18, 23, 62}
//                     };
//          int total = 0; // 합계를 저장하기 위한 변수
//          float average = 0; // 평균을 저장하기 위한 변수
//          for(int i=0; i<arr.length;i++){
//             for(int j=0; j<arr.length;j++){
//                total[i] += arr[i][j];
//                average[i] = (int)((float)(total[i]*100/score.length+0.5))/100F;
//             }
//             
//          }
//          System.out.println("total = " + total);
//          System.out.println("Average = " + average);


//      4[5-5] 거스름돈을 몇 개의 동전으로 지불할 수 있는지를 계산하는 문제이다. 
//              변수 money의 금액을 동전으로 바꾸었을 때 각각 몇 개의 동전이 필요한지 계산해서 출력하라. 
//              단, 가능한 한 적은 수의 동전으로 거슬러 주어야한다. 

//          int[] coinUnit = { 500, 100, 50, 10 };
//          int money = 2790;
//          int result = 0; //임시 저장값
//          for(int i=0; i<coinUnit.length;i++){
//                result = money/coinUnit[i]; //money를CoinUnit을 나눈 몫을 변수 result에 저장한다.
//                System.out.println(coinUnit[i]+"원"+result+"개"); 
//                money = money - result*coinUnit[i]; //나눠준 값을 다시 곱한 후 전체에서 빼서 넣어준다.
//             }
//          
          
          

//      4[5-6] 다음은 1과 9사이의 중복되지 않은 숫자로 이루어진 3자리 숫자를 만들어내는 프로그램이다.
//      ※ 임의의 값을 사용했기 때문에 실행결과와 다를 수 있다.
//
          int[] ballArr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
          int[] ball3 = new int[3];
          int result = 0;//임시 저장값 변수
          // ballArr의 index순서대로 index의 요소와 임의의 요소를 골라서 값을 바꾼다.
          for(int i=0; i<ballArr.length;i++){//index를 도는 포문
             int j = (int) (Math.random()*8+1); //ballArr length로 맞춰준다.
             result = 0;
             //변수를 확인함

             result = ballArr[i];
             ballArr[i] = ballArr[j];
             ballArr[j] = result;
          
          }

          
//           ballArr의 앞에서 3개를 ball3로 복사한다.
	   		for(int i=0; i<3; i++){
	   			ball3[i] = ballArr[i];
	}
//
//           ball3의 값을 출력한다.
	   		for (int i=0; i<ball3.length;i++){
	   			System.out.println(ball3[i]);
	   		}
          


//      3[5-7] 다음은 배열 answer에 담긴 데이터를 읽고 각 숫자의 개수를 세어서 개수만큼 '*'을 찍어서 그래프를 그리는 프로그램이다.
          int[] answer = { 1, 4, 3, 2, 1, 2, 3, 2, 1, 4 };
          int[] counter = new int[4];
          int sum2 = 0;//
          String[] star;//별찍기
          // answer의 요소들 중 1이면 counter의 0번방을 증가, 2이면 counter의 1번방을 증가
          // 3이면 counter의 2번방을 증가, 4이면 counter의 3번방을 증가.
         for(int i=0; i<answer.length;i++){
        		 counter[answer[i]-1]++;          
         }
//	   		counter 별찍기
         for (int i = 0; i < counter.length; i++) {
        	 System.out.print(i+1+":"+counter[i]+"");
        	 for(int j =0; j < counter[i]; j++){
        	 	System.out.print("*");
        	 }
        	 System.out.println();
         }
//           hide : answer의 값의 범위를 측정하여 최대 5개의 통계 만들기  
//          ???????????
          
          
//      5[5-8] 문제 5-5에 동전의 개수를 추가한 프로그램이다. 커맨드라인으로부터 거슬러 줄 금액을 입력받아 계산한다. 보유한 동전의 개수로 거스름돈을 지불할 수 없으면, '거스름돈이 부족합니다.'라고 출력하고 종료한다. 지불할 돈이 충분히 있으면, 거스름돈을 지불한 만큼 가진 돈에서 빼고 남은 동전의 개수를 화면에 출력한다. (1)에 알맞은 코드를 넣어서 프로그램을 완성하시오.
//
         if(args.length!=1){
            System.out.println("한개의 숫자만 입력해 주세요.");
            System.exit(0);
          }
          // 문자열을 숫자로 변환한다. 입력한 값이 숫자가 아닐 경우 예외가 발생한다.
          int money = Integer.parseInt(args[0]);
          System.out.println("money="+money);
          int[] coinUnit =  { 500, 100, 50, 10 } ; // 동전의 단위
          int[] coin = { 5, 5, 5, 5 } ; // 단위별 동전의 개수

          for(int i=0;i<coinUnit.length;i++) {
            int coinNum = 0;
//            (1) 아래의 로직에 맞게 코드를 작성하시오.
//            1. 금액(돈)을 동전단위로 나눠서 필요한 동전의 개수(coinNum)를 구한다.
            coinNum = money/coinUnit[i];
//            2. 배열 coin에서 coinNum만큼의 동전을 뺀다.
//            (만일 충분한 동전이 없다면 배열 coin에 있는 만큼만 뺀다.)
             if(coin[i] >= coinNum){
            	 coin[i] -= coinNum;
             }else{
            	 coin[i] = 0;
             }
//            3. 금액에서 동전의 개수(coinNum)와 동전단위를 곱한 값을 뺀다.
            money = coinNum*coinUnit[i];
            
          
            System.out.println(coinUnit[i]+"원: "+coinNum);
          }

          if(money > 0) {
            System.out.println("거스름돈이 부족합니다.");
            System.exit(0); // 프로그램을 종료한다.
          }

          System.out.println("=남은 동전의 개수 =");
          for(int i=0;i<coinUnit.length;i++) {
            System.out.println(coinUnit[i]+"원:"+coin[i]);
          }


//      5[5-9] 주어진 배열을 시계방향으로 90도 회전시켜서 출력하는 프로그램을 완성 하시오.
//좌표를90도로 돌렸을 때 어떤 좌표로 가는지 찾아야함 
//          
          char[][] star2 = {
                {'*','*',' ',' ',' '},
                {'*','*',' ',' ',' '},
                {'*','*','*','*','*'},
                {'*','*','*','*','*'}
              };
          char[][] result2 = new char[star2[0].length][star2.length];

          for(int i=0; i < star2.length;i++) {
            for(int j=0; j < star2[i].length;j++) {
              System.out.print(star2[i][j]);
            }
            System.out.println();
          }
          System.out.println();

          for(int i=0; i < star2.length;i++) {
            for(int j=0; j < star2[i].length;j++) {
              result2[i][j] = star2[3-j][i];
             
              
            }
          }

          for(int i=0; i < result2.length;i++) {
            for(int j=0; j < result2[i].length;j++) {
              System.out.print(result2[i][j]);
            }
            System.out.println();
          }
        }
      

   }


