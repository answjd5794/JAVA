package j_jdbc;

public class JDBC_Basic {
	public static void main(String[] args) {
		/*
		 1. JDBC
		  - java database connectivity
		  - JDCB 드라이버 : ojdbc6.jar
		  
		  2. JDBC 활용
		   - JDBC 드라이버를 로딩
		   	: Class.forName("")
		   - JDBC 접속
		   	: DriverManager.getConnection()
		   - 질의(sql)
		   	: Statement, Prepared Statement
		   - 질의 결과 반납
		    : ResultSet
		   - 종료(자원반납)
		    : close()
		 */
		
		
	}
}
