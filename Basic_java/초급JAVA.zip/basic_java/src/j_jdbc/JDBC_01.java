package j_jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC_01 {
	public static void main(String[] args) {
		
		//연결 개체 생성
		Connection conn = null;
		//질의 개체 생성
		Statement stmt = null;
		//질의 결과 받음
		ResultSet rs = null;
		
		
		//2.예외 잡기 위해 try-catch돌려줌
		try {
			//1.드라이버 로딩함
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//3.접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
											//@IP //비밀번호 //오라클설치할때됨
			//4.oracle접속할 계정과 비밀번호
			String id = "moon";
			String pw = "java";
			
			//5.DriverManager.getConnection(url,id,pw);
			conn = DriverManager.getConnection(url, id, pw);
			
			//7. 질의
			stmt = conn.createStatement();
			String mem_id = "a001";
			String sql = "SELECT 	* "
						+ "FROM 	MEMBER " //문자열 합쳐져 있으니까 뒤에 띄어쓰기를 해야됨. 
						+ "WHERE 	MEM_ID = '"+mem_id+"'";
			//오라클은 구문되지 않는 문자만 대문자로 쓰고, 구분되는 문자는 소문자로쓰면
			//인지하게 편하게됨
			
			//8. select 질의 및 결가 저장 
			//excuteUpate-> 반환타입 a
			// 등/수/삭
			rs = stmt.executeQuery(sql);
			//9. 몇개인지도 모르고 set은 순서가 없으니까  for문이 아니라 while문으로 해야됨
			while (rs.next()) {
				//MEM_NAME은String이니까 String 변수에 담아줘서 String으로 가져옴 
				String mem_name = rs.getString("MEM_NAME");
				System.out.println(mem_name);
			}
		
		
			//6.DriverManager를 했을 때 오류가 발생할 수 있으므로 try-catch를 통해서 예외처리
			//한꺼번에 많은 try-catch를 할 수 없으니까 catch를 여러번 써주면서 잡아줌
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 실패");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속 실패!!");
		} finally{ //10. 결과-질의-접속을  반환하면서 클로즈해줌
			
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("자원반납실패");
			}
			
		}
		
	}
}
