package i_collection;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class StackTest {
	public static void main(String[] args) {
		
		//선입후출
		//stack은 stack객체를 생성해야지 사용할 수 있음 인터페이스 생성x
		Stack<String> s = new Stack<>();
		
		s.push("0");
		s.push("1");
		s.push("2");
		System.out.println("================stack=============");
//		System.out.println(s.pop());//2
//		System.out.println(s.pop());//1
//		System.out.println(s.pop());//0
//		System.out.println(s.pop());//비어있는데 달라고 하면 터짐
		
		while(!s.empty()){
			System.out.println(s.pop());
			
		}
		//선입선출
		//인터페이스라서 객체생성 x
		Queue<String> qu = new LinkedList<>();
		
		qu.offer("0");
		qu.offer("1");
		qu.offer("2");
		
		System.out.println("===============Queue===============");
		
		while(!qu.isEmpty()){
			System.out.println(qu.poll());
			
		}
	}
}
