package i_collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MapTest {
	public static void main(String[] args) {
		
		//Map을 타입을 가져다가 고대로 쓰기 위해서는 hashMap에 <>를 붙여줘야한다.
		Map<String, Integer> param = new HashMap<>();
		
		//put을 이용해서 값을 넣어줌
		param.put("이현무", 50);//AutoBoxing
		param.put("김근호", 60);//AutoBoxing
		param.put("이경륜", 15);//AutoBoxing
		//update와 insert를 동시에 하기 때문에 같은 키가 없으면 새로 생성/추가이기때문에 null이 나오고
		System.out.println(param.put("이운주", -100));
		//다시 같이 불러오면 이전의 값을 가져온다
		System.out.println(param.put("이운주", -10));		
		
		//R
		int ju = param.get("이운주");
		System.out.println(ju);
		System.out.println(param);
		
		//D
//		param.remove("김근호")
		System.out.println(param.remove("김근호"));
		System.out.println(param);
		
		
		Map<String, String> mem = new HashMap<>();
		mem.put("mem_id","a001");
		mem.put("mem_pw","asdfasdf");
		mem.put("mem_id","a002");
		mem.put("mem_pw","answjd");

//		SELECT * 
//		FROM MEMBER
//		WHERE MEM_ID = mem.get("mem_id");
//		AND   MEM_PW = mem.get("mem_pw");
		
		
		
	}
}
