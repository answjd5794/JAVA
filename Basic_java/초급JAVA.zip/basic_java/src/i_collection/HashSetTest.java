package i_collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HashSetTest {
	public static void main(String[] args) {
		
		Set<Integer> se = new HashSet<>();

//		se.add(5);
//		se.add(2);
//		se.add(3);
//		se.add(1);
//		se.add(4);
		
		
		//숫자가 중복되지 않게 만들어 주는것. ex)Lotto 6개를 고를 때 까지 돌림
		for (int i = 0; i < 10; i++) {
			int random = (int)(Math.random()*35+1);
			boolean result = se.add(random);
			System.out.println(result);
			
		}
		//정렬
		List<Integer> se1 = new ArrayList<>(se);
		Collections.sort(se1);
		System.out.println(se1);
		
	}
}
