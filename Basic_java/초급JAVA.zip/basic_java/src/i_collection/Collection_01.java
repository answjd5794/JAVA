package i_collection;

public class Collection_01 {
	public static void main(String[] args) {
		/*
		 1. collection framework
		  - Collection
		  	: 데이터 집합(그룹)
		  - Framework
		  	: 일을 하기 위한 틀
		  	: 표준화가 가능하다.
		  	
			
								
		  2. 핵심 인터페이스
		   - List
		   	: 순서가 있다, 데이터의 증복을 허용
		   	구현체 : ArrayList, vector, stack, LinkedList..
		   	: 대기표 명단, 
		   	
		   - Set
		   	: 순서가 없다, 데이터의 중복을 비허용
		   	구현체 : HashSet, TreeSet
		   	: 정수의 집합
		   
		   - Map		
		   	: key와 value로 이루어져 있다.		
			: 순서가 없다.
			: key는 중복을 허용x, value는 중복 허용o
			구현체 : HashTable(예전에 씀), HashMap, TreeMap(검색용도로 사용)
			: 지역번호, 우편번호
		  													collections
		  						collection												 map(제네릭타입 두 개, 순서x, 데이터 중복 key로 구분)
 			list(순서가 있음,데이터의 중복을 허용),	 set(순서가 없음,데이터의 중복 허용x)				ex) key는 중복 허용 x, value는 중복 허용o
			vector,stack,ArrayList			 HashSet, TreeSet							TreeMap, HashTable, HashMap
		 
		 
		 3. ArrayList
		   - 배열을 사용하였을 때, 길이가 한번 정하면 변경이 불가한 단점을 보완하기 위해 만들어 졌다.
		   - 메서드를
		   	: add() 	-> 객체를 추가한다.
		   	: remove()  -> 객체를 제거한다.
		   	: get(int index) 			 -> index번째 객체를 얻어온다. (주소는 가만히 있고 값을 바꾸는 개념)
		   	: set(int index, Object obj) -> index번째 객체를 교체한다. (Object이기 때문에 주소를 변경한다는 개념)
		   	
		 4. LinkedList
		   	- 자신의 데이터와 다음 데이터의 주소를 갖고 있다.
		   	- 이전 요소를 찾을 수가 없다.
		   	
		 5. DoubleLinkedList
		    - 자신의 데이터와 이전 데이터의 주소, 다음 데이터의 주소를 가지고 있다.
		
		 6. stack
		    - First In Last Out (FILO)
		    - push() 객체 추가
		    - pop() 객체 추출 (값을 빠져서 아예 사라짐)
		    - search() 객체 찾기
		    - peek() 가장 위의 객체를 가져온다.
		    
		 7. Queue (인터페이스라서 객체생성이 불가능함)
		    - First In First Out(FIFO)
		    - offer() 추가
		    - poll() 추출
		 
		 ========================================================================================    
		 8. HashSet
		    - 새로운 요소를 추가하기 위해 add나 addAll()를 사용할 때 중복 추가가 되지 않는다. -> 반환타입은 false. 
		 
		 9. Map - HashMap
		 	- 키(key)와 값(value)로 이루어져 있다.
		 	- 순서가 없기 때문에 키는 중복을 비허용하고 값을 중복을 허용한다.
		 	- 키와 값의 type으로 Obejct형태이지만 일반적으로는 키의 경우는 String type으로 많이 사용한다.
		 	  value는 Object형 테이블.
		 	- method를
		 	  : put() : 객체를 추가
		 	  : get(키) : 원하는 객체의 값을 가져온다.
		 	  : //update는 없음
		 	  : remove(키) : 원하는 객체의 값을 삭제한다.
		 	  
		    
		    
		 */
		
		
	}
}
