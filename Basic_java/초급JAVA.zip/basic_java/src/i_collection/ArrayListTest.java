package i_collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListTest {
	public static void main(String[] args) {
		//앞을 인터페이스 타입 , 뒤에는 구현한 구현체의 객체
		List<Integer> list1 = new ArrayList<>();
		list1.add(new Integer(5));//Integer의 객체
		list1.add(2);
		list1.add(3);
		list1.add(1);
		list1.add(4);
		//add메서드 자체가 객체타입을 원하는데 자동으로 객체타입으로 변환해주는 것
		//AutoBoxing

		//list1에 있는 값들을 list2에 똑같이 복붙시켜줌
//		List<Integer> list2 = new ArrayList<>(list1);
		//문자열 잘라내는것 substring
		List<Integer> list2 = new ArrayList<>(list1.subList(1, 4));
		System.out.println(list1);
		System.out.println(list2);
		//주소가 나와야 하는데 값이 나온다.
		//toString 메서드가 오버라이드 되었다.
		
		//Read
		//알맹이만 꺼내서 변수에 넣어주는것
		//UnBoxing
		int a = list1.get(2);
		System.out.println(a);
		
		//Delete
		list1.remove(2);//5 2 3 1 4
						//삭제되면서 인덱스가 앞으로 하나씩 땡겨져옴
		System.out.println(list1);
		
		//Update ****이해잘안됨*****
		int change =  new Integer(10);
		int after = list1.set(1, change);//1번 인덱스를 새로운 인티저 타입 10으로 바꾸어라.
		//반환타입을 통해서 바뀌기 전과 바뀐 후	
		System.out.println("바뀌기전 : " + after + "바뀐 후 : " + change);
		System.out.println(list1); // 5 10 1 4
		
		//그동안 정렬하느라 고생하셨습니다..
		//정렬해주는 메서드가 있어요...

		//List만 정렬해줌
		Collections.sort(list1);
		System.out.println(list1);
		
		
	}
}
