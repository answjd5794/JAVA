package h_javalang;

public class EqualsTest_01 {
	public static void main(String[] args) {

		Value v1 = new Value(100);
		Value v2 = new Value(100);
		
		System.out.println(v1 == v2);//주소 비교
		System.out.println(v1.equals(v2));//v2의 주소값을 가져간다. 
										  //f2 눌러보면 Object를 받으니까 다형성에 의해 자동 최상위 클래스로 Upcasting된다.
		
		
	}
}

class Value{
	
	int value;
	Value(int value){
		this.value = value;
	}
	
}