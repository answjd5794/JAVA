package h_javalang;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JavaLangBasic {
	public static void main(String[] args) {
		/*
		 1. java.lang 패키지
			- java 프로그램이 기본적으로 필요한 클래스들을 모아놓은 패키지이다.
			- String, Object, System...
			
		 2. Object
		 	- Object클래스는 멤버변수없이 11개의 메서드로 되어 있다.
		 
		 	- equals()
		 	  : 참조변수가 가르키는 주소를 비교한다.
		 	  : 주소가 아닌 해당 인스턴스가 가지고 있는 값을 비교하게 하려면 equals()를 오버라이드 해야한다.
		 	  : equals()가 오버라이드 되어있는 클래스를 
		 	  -> String, File, Date...
		 	
		 	- hashCode() - 10진수로 이루어져 있다.
		 	  : 객체의 주소에서 해시코드를 만들어 반환한다.
		 	  	ex)asdfas@2c53  
		 	  : String 클래스는 같은 문자열을 가지고 있다면 해쉬 코드를 반환하게 만들어져 있다.
		 	  	String A = "ab", String B ="ab"
		 	  	같은 주소를 반환해준다.
		 	
		 	- toString()
		 	  :	Object의 toString() 구성
		 	  	-> return getClass.getName() + "@" + Integer.toHexString(hashCode()); 
		 	  	클래스의 정보 중에 이름만 가지고옴 
		 	  : toString() 오버라아ㅣ드 되어있는 클래스들
		 	   -> String...
		 	   
		 	- getClass()
		 	  : 클래스의 정보를 얻어올 때 사용한다.
		 	  (1) 생성된 객체로부터 얻는 방법
		 	  	 Class obj = new Person(클래스명).getClass(); 
		 	  (2) 클래스 리터럴로부터 얻는 방법
		 	  	 Class obj = Person.class;
		 	  (3) 클래스 명으로부터 얻는 방법 (가장많이 사용함)	
		 	   	 Class obj = Class.forName("Person(클래스명)"); //클래스라는 클래스에 있는 클래스 메서드
		 		 ClassNotFoundException이 생길 수 있는 위험성이 있음.
		
		 3. String
		 	- 다른 언어에서는 문자열을 char형 배열로 다룬다. 하지만 java에서는 문자열을 다룰 수 있는 String class를 제공한다.
		 	- 문자열을 합칠 때는 합쳐진 문자열을 저장할 인스턴스 생성된다.
		 	
		 	- 문자열의 비교
		 	 : 문자열 리터럴을 만드는 방법과, 객체의 생성자를 이용할 수 있다.
		 	
		 	- 인코딩 변환
		 	 : 이클립스의 기본 인코딩 방식은 "MS949"
		 	 : 윈도우의 기본 인코딩 방식은 "CP949"
		 	 : 우리가 사용하는 인코딩 방식은 "UTF-8"
		 	 
		 	- 문자열 format
		 	 : 기본형 타입을 String 타입으로 변환
		 	  
		 	  1) 빈 문자열을 더하는 방식(가장 안좋음)
		 	  	int a = 10;
		 	  	String b = a + " ";
		 	  
		 	  2) valueOf 메서드
		 	  	String b = String.valueOf(a);
		 	  	
		 	  :String 타입을 기본형으로 변환
		 	   1) wrapper 클래스를 이용하는 방식
		 	   	String b = "123";
		 	   	int c = Integer.paresInt(b); //문자열을 기본형 값으로 변환해주는 것
		 	   2) wrapper 클래스의 진수
		 	   	String b = "234";
		 	   	int c = Integer.paresInt(b,8);//b를 8진수로 하고 이를 10진수로 다시 변환해줌.
		 	   	
		 	 
		 4. String Buffer, StringBuilder
		 	- 문자열을 합치기 위해서 사용한다.
		 	
		 5. wrapper
		 	- 자바는 모든 것을 객체로 다루어야 한다.
			 	기본형	|	Wrapper
			 	boolean |	Boolean
			 	byte    |	Byte
			 	char    |	Character **
			 	int     |	Integer **
			 	float   |	Float
			 	long    |	Long
			 	double  |	Double
			 	short	|	Short
		 	
		 	- 기본형 타입을 wrapper클래스 타입으로 변환해 주는 것 : AutoBoxing
		 	- wrapper클래스 타입을 기본형 타입으로 변환해 주는 것 : UnBoxing
		 	
		 	
		 6. 정규식
		 	- 텍스트 데이터에서 원하는 형태의 문장을 찾기 위해 만들어 졌다.
		 	- 정규식 순서
		 	 : 패턴정의 
		 	 	-> Pattern class를 이용하여 패턴을 정의한다.
		 	 	Pattern p = Parttern.compile("[a-z]*");
		 	 	
		 	 : Text와 비교
		 	 	-> Matcher 클래스를 이용하여 패턴과 텍스트를 비교한다.
		 	 	Matcher m  = p.matcher("text");
		 	 	
		 	 	m.matches() 일치하면 true, 일치하지 않으면  false
		 	 	
		 	- 정규식 문법
		 	  ^ : 문자열의 시작 ex) a^ a로시작하는 거
		 	  $ : 문자열의 끝
		 	  . : 임의의 한문자 (키보드에 있는 특수문자 포함) 단, \ 역슬러쉬는 포함되지 않는다.
		 	  * : 0개 또는 무한정 있을 수 있다.
		 	  + : 0개는 제외 1개이상 (무한대까지)있을 수 있다.
		 	  ? : 0개 또는 한개가 있을 수 있다.
		 	 () : (abc) -> 하나의 문자로 인식해서 abc가 무조건 나와야 한다고 뜻함
		 	 	  하나의 문자열을 하나의 문자로 인지한다.
		 	 {}	: 반복 횟수를 지정한다. {3,5} -> 3번 반복, 4번 반복, 5번 반복을 뜻함.
		 	  	  				   {4,} -> 무조건 4번이상 반복
		 	 [] : 범위를 지정할 때 사용한다. [abc] -> abc 중에 하나 (or뜻)
		 	  	  				   	  [a-c] -> a부터 c까지 하나
		 	  	  				   	  [a-zA-z0-9] -> or생략가능 (영문자 또는 숫자)
		 	  | : or연산을 수행할 때 사용 (소괄호와 함께 씀)
		 	 \s : 공백 문자
		 	 \S : 공백을 제외한 모든 문자
		 	 \w : 영어 대문자 또는 소문자 또는 문자-> [a-zA-z0-9]				   	  
		 	 \d : 숫자 [0-9] 
		 	  
		 	  
		 	  
		 */
		
		//0개 또는 무한정으로 저 사이안에만 있으면 true 
		//하나라도 다른게 들어가면 안된다.
		Pattern p = Pattern.compile("[a-z]*");
		Matcher m = p.matcher("aAAA");
		System.out.println(m.matches());
	}
}
