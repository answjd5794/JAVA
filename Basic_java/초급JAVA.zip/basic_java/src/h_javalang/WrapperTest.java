package h_javalang;

public class WrapperTest {
	public static void main(String[] args) {
		
		Integer i1 = new Integer(10);
		Integer i2 = new Integer(10);
		
		//원래 주소가 나와야되는데 값이 나오기 때문에
		//toString Method가 오버라이드 되어있다.
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i1 == i2);
		
		//원래 주소가 나와야되는데 값이 나오기 때문에
		//equals Method가 오버라이드 되어있다.
		System.out.println(i1.equals(i2));
		
		Integer[] intArr = new Integer[3];
	/*	intArr[0] = new Integer(5);
		intArr[1] = new Integer(10);
		intArr[2] = new Integer(15);
									*/
		intArr[0] = 5;
		intArr[1] = 10;
		intArr[2] = 15;
		//기본형 타입을 wrapper타입으로 바꿔주는 auto Boxing
		
		//Unboxing
		int b = intArr[0]; 
		
	}
}
