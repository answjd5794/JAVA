package h_javalang;

import java.util.Arrays;

public class GetClassTest {
	public static void main(String[] args) throws ClassNotFoundException {
		//1. 클래스의 정보를 객체로부터 얻는 방법
		Class re1 = new Person(2314L).getClass();//Person의 객체를 생성하고 re1에 담아줌
		System.out.println(re1.getName());
		System.out.println(Arrays.toString(re1.getInterfaces()));//배열로 받는 메서드를 Arrays.toString을 통해서 문자열로 변환해줄 수 있다.
		
		//2. 클래스 리터럴로부터 얻는 방법
		Class re2 = Person.class;//클래스명.class
		System.out.println(re2.getName());
		System.out.println(Arrays.toString(re2.getInterfaces()));//배열로 받는 메서드를 Arrays.toString을 통해서 문자열로 변환해줄 수 있다.
		
		//3. 클래스 명으로부터 얻는 방법
		Class re3 = Class.forName("h_javalang.Person");//문자열로 찾으면 에러가 발생할 수 있으니 throw로 넘겨주던가 try/catch를 통해서 잡아주던가 해야됨
														//패키지명.클래스명을 통해서 패키지까지 적어줘야지 패키지->클래스를 통해서 찾을 수 있다.
														//안해주면 터져서 ClassNotFoundException이 생김
		System.out.println(re3.getName());
		System.out.println(Arrays.toString(re3.getInterfaces()));
	}
}



