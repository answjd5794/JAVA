package h_javalang;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class FileEncodingTest {
	public static void main(String[] args) throws UnsupportedEncodingException {
		String str = "가나";
//		String str = "ab";
		
		byte[] cpStr = str.getBytes("MS949");//문자열을 byte형 숫자로 만든 후 배열 형태로 뽑아내는 것
		byte[] msStr = str.getBytes("CP949");//문자열을 byte형 숫자로 만든 후 배열 형태로 뽑아내는 것
		byte[] utStr = str.getBytes("UTF-8");//문자열을 byte형 숫자로 만든 후 배열 형태로 뽑아내는 것
		
		System.out.println(Arrays.toString(cpStr));
		System.out.println(Arrays.toString(msStr));
		System.out.println(Arrays.toString(utStr));//영문자는 인코딩에 전혀 관련이 없다.
	}
}
