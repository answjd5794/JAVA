package h_javalang;

import java.io.Serializable;

public class EqualsTest_02 {
	public static void main(String[] args) {
		Person p1 = new Person(9706242403924L);
		Person p2 = new Person(9706242403924L);
		
		System.out.println(p1 == p2);//false
		System.out.println(p1.equals(p2));//true로 나오기 위해서  toString() 오버라이드 을 해줘야지 true로 나옴
										  //해주지 않으면 주소만 비교하기 때문에 false가 출력된다.
		
//		String a = null;
//		System.out.println(a.equals(""));//앞에는 null이 오면 안된다.
//		System.out.println(p1);
		
		System.out.println(p1.toString());//toString()
		System.out.println(p1.hashCode());//hashCode()
		
	}
}

class Person implements Serializable{
	long regNo;
	
	Person(long regNo){
		this.regNo = regNo;
		
	}
	
	//alt + shift + s + v
	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if(obj instanceof Person && obj != null){
			//boolean result =  this.regNo == ((Person)obj).regNo;
			result = this.regNo == ((Person)obj).regNo;
			
		}
		return result;
	}

	//alt + shift + s + s + enter
	@Override
	public String toString() {
		return "Person [regNo=" + regNo + "]";
	}
}

