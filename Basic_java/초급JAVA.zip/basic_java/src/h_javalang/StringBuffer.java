package h_javalang;

public class StringBuffer {
	public static void main(String[] args) {
		
		/*
		String str = "a";
		str += "a";
		str += "a";
		str += "a";
		str += "a";

		
		String str = "a";
		new StringBuffer(str).append("a").toString();
		*/
		
		/*
		 String str = "a";
		
		long start = System.currentTimeMillis(); //시스템의 현재 시간을 천분의 일초로 바꿔준것.
		
		for (int i = 0; i < 300000; i++) {
			str += "a";
		}
		long end = System.currentTimeMillis(); //시스템의 현재 시간을 천분의 일초로 바꿔준것.
		System.out.println(end-start);//포문이 돌아가는데 걸리는 시간
		
		 */

		StringBuilder sb = new StringBuilder("a");

		long start = System.currentTimeMillis();
		for (int i = 0; i < 300000000; i++) {
			sb.append("a");

		}
		long end = System.currentTimeMillis();
		System.out.println(end-start);

		
	}
}
