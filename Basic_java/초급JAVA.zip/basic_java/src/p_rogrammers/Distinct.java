package p_rogrammers;

public class Distinct {
	public static void main(String[] args) {
		Solutio2 s = new Solutio2();
	}
}
//나누어 떨어지는 숫자배열
//class Solution {
//    public int[] solution(int[] arr, int divisor) {
//    	//int[]  answer
//    	//anwer[0,1,2,3] di
//        int[] answer = {};
//        for(int i=0; i<arr.length;i++){
//        	answer[i];
//        	if(i%divisor == 0){
//        		
//        		return answer[i];
//        	}
//        	//나누어 떨어지는 값이 아니면 -1을 리턴한다.
//        	else{
//        		int[] result = {-1};
//        	return result;	
//        	}
//        	
//        	
//        }
//        
//        
//    }
//}

 class Solutio2 {
    public int[] solution(int []arr) {
        int[] answer = {};
        int x = 0;
        for(int i =0; i<arr.length;i++){
            if(arr[i] != answer[x]){
                answer[x] = arr[i];
                
            }else{
                x++;
            }
            
            
        }
        
        
        // [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
        System.out.println("Hello Java");

        return answer;
    }
    
 }    