package p_rogrammers;

public class Dan_2 {
	public static void main(String[] args) {
		int x = (int)(Math.random()*101);
		System.out.println(x);
		
		
	}
}
