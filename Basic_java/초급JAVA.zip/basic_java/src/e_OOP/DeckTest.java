package e_OOP;

import java.util.Arrays;

public class DeckTest {
	public static void main(String[] args) {
		/**
		 * doc주석 달아놓기
		 * 
		 */
//		System.out.println(c.toString());//SPADE,A
//		Card c2 = new Card(2,5);//1,1
//		System.out.println(c2.toString());//DIAMOND,5
//		Card c = new Card();//1,1

//		Deck d = new Deck();
		//9. 카드 한 벌(deck)의 객체를 생성
//		Deck d = new Deck();
////		System.out.println(Arrays.toString(d.c));
//	    //10. 0번 index의 카드 한 장을 뽑기
//		Card result = d.pick(0);
//		System.out.println(result);
//	    //11. 임의의 index번째 카드 한 장을 뽑기
//		Card result2 = d.pick();		
//		System.out.println(result2);
//	    //12. 카드를 자동 섞기
//		d.shuffle();
//		
//	    //13. 0번 index의 카드 한 장을 뽑기
//		d.pick(0);
//	    //14. 카드 1000번 섞기
//		d.shuffle(1000);
//	    //15. 0번 index의 카드 한 장을 뽑기
//		Card result3 = d.pick(0);
//		System.out.println(result3);
//	      System.out.println(Arrays.toString(d.c));
		
//		//8. 카드 한 벌의 객체를 생성
	      Deck d = new Deck();
		
//	      //9. 0번 index의 카드 한 장을 뽑기
	      Card result = d.pick(0);
	      System.out.println("0번 인덱스의 카드 한장:" + result);
//	       //10. 임의의 index번째 카드 한 장을 뽑기
	      Card result2 = d.pick();
	      System.out.println("임의의 인덱스의 카드 한장:" + result2);
	      
//	       //11. 카드를 자동 섞기
	      d.shuffle();
	       
//	       //12. 0번 index의 카드 한 장을 뽑기
	      Card result3 = d.pick(0);
	      System.out.println("0번 인덱스의 카드 한장:" + result3);
//	       //13. 카드 1000번 섞기
	      d.shuffle(1000);
	      
//	       //14. 0번 index의 카드 한 장을 뽑기
	      Card result4 = d.pick(0);
	      System.out.println("0번 인덱스의 카드 한장:" + result4);
		
		
	}
}

class Deck{
	//1. 카드의 수량을 저장할 수 있는 변수 CARD_NUM을 선언하고 
	//CARD 클래스의 상수를 이용하여 초기화 하여라.
	//Card의 수량은 종류*
	static final int CARD_NUM = Card.KIND_MAX * Card.NUM_MAX;
	
	
	//2. 카드 52장을 저장할 수 있는 변수 c를 선언 및 생성하여라.
	//Deck은 Card를 포함한다.(포함관계)
	//Card 객체 배열은 참조변수 배열이고, 실제로 저장된 것은 객체가 아니라 객체의 주소이다.
	Card[] c = new Card[CARD_NUM];
	
	
	
	//3. 기본생성자를 만들어라.
	//c의 모든 방들의 값을 1,1-> 4,13까지의 카드로 초기화 하여라.
//	c[0] = (1,1)-> KIND_MAX(1부터 4까지), NUM_MAX(1부터 14까지)
//	c[1] = (1,2)
//	c[2] = (1,3)
//	c[3] = (1,4)
//	c[4] = (1,5)
//	c[5] = (1,6)
//	c[6] = (1,7)
//	c[7] = (1,8)
//	c[8] = (1,9)
//	c[9] = (1,10)
//	c[10] = (1,11)
//	c[11] = (1,12)
//	c[12] = (1,13)
//	c[13] = (2,1)
//	....
//  c[52] = (4,13)
//	c[i++] = (Card.KIND_MAX,Card.NUM_MAX)????
//			= (i,j)
	
	//시작: 1부터, 증가 +1, 14까지니까 j<15 => j<Card.NUM_MAX+1
	//시작: 1부터, 증가+1, 4까지니까 i<5 => i<Card.KIND_MAX+1
	
	int arrayNum = 0;//c배열의 방을 하나씩 올려주는 변수
	Deck(){// Deck 클래스의 기본생성자
		for(int i=1; i <Card.KIND_MAX+1; i++){
			for(int j=1; j <Card.NUM_MAX+1; j++){
//				Card ac = new Card(i,j);
				c[arrayNum++] = new Card(i,j);
				//c[(kind-1)*13+(number-1)]
			}
			
		}
	}
	   //인자값으로 c의 방번호를 받아서 해당하는 방의 카드한장을 반환하는 메서드 pick()
	  //4. c에서 임의의 index번째 카드 한 장을 반환하는 메서드(pick)를 작성하여라.
	
	//Deck 클래스의 멤버변수  Card로 선언하여 포함관계를 맺어준다.
	//Card pick()이 Card타입이 된다.
	//임의의 index값이니까 랜덤 변수하나를 생성해준다. int a = (int)(Math.random()*CARD_NUM)
//	Card pick(){
//	      int a = (int)(Math.random()*CARD_NUM);
//	      Card result = c[a];
//	      return result;
//	   }

	
	//4. 사용자로부터 입력받은 index번째 카드 한장을 반환하는 메서드 pick
	Card pick(int index){
		Card result = c[index];
		return result;
		
	}
	
	

//	  //5. 사용자로부터 입력받은 index번째 카드 한 장을 반환하는 메서드(pick)를 작성하여라.
//	  //  단. 입력받은 값이 0~51사이의 정수라면  입력받은 index번째 카드 한 장을 반환하고
//	  //  그렇지 않은 경우에는 "랜덤번호"를 출력하고 임의의 한 장을 반환하도록 하여라.
//	
//	Card pick(int b) {
//			if( 0 <= b  && b < CARD_NUM){
//				Card result = c[b];
//				return result;
//			}
//			else {
//				System.out.println("랜덤 번호");
////				int a = (int) (Math.random() * CARD_NUM);
////				 Card result2 = c[a];
//				Card result = pick();
//				return result;
//			}	
//		}


	//5. pick c의 방중에 임의의 index번쨰 카드 한장을 반환하는 메서드
	//단, 4번에서 만든 pick메서드를 활용하라
	//4번과 5번은 오버로딩 관계
	Card pick(){
		int randomIndex = (int)(Math.random()*CARD_NUM);
//		Card randomIndex = pick();
		Card a = pick(randomIndex);
		return a;
		
	}
	


	  //6. c의 카드를 섞는 메서드(shuffle)을 작성하여라. - 자동 섞기
	  //  단. 카드 섞는 법 : 연습문제 5-6의 방법을 활용
	
//	void shuffle(){
//		Card tmp;//임시저장값 변수
//		 for(int i=0; i<CARD_NUM;i++){
//	         int randomNum = (int) (Math.random()*CARD_NUM); 
//	             randomNum = 0;
//	             //변수를 확인함
//
//	             tmp = c[i];
//	             c[i] = c[randomNum];
//	             c[randomNum] = tmp;
//	          
//	          }
//		
//	}
//	

	//6. c의 카드들을 섞어주세요. shuffle
	// 연습문제 5-6번의 형태를 이용하세요
	
	void shuffle(){
		 for(int i=0; i<CARD_NUM;i++){
	         int randomNum = (int) (Math.random()*CARD_NUM); 
	         Card tmp = c[i];
	         c[i] = c[randomNum];
	         c[randomNum] = tmp;
	        		 

	          
	          }
		
	}



	  //7. 사용자로부터 입력받은 횟수만큼 c의 카드를 섞는 메서드(shuffle)을 작성하여라.
	  //   단. 임의의 방 두개를 뽑아 두개의 index번째 요소의 위치를 바꾼다. 이를 사용자로
	  //   부터 입력받은 횟수만큼 반복한다.
	void shuffle(int cycle) {
		int card1 = (int) (Math.random() * CARD_NUM);
		int card2 = (int) (Math.random() * CARD_NUM);
		
		for (int randomNum = 0; randomNum < cycle; randomNum++) {
			Card tmp = c[card1];
			c[card1] = c[card2];
			c[card2] = tmp;

		}
	}

	
}






class Card{
	static final int KIND_MAX = 4;
	static final int NUM_MAX = 13;

	static final int SPADE = 1;
	static final int DIAMOND = 2;
	static final int HEART = 3;
	static final int CLOVER = 4;
	
	static int width =100;
	static int height =100;
	
	int number;
	int kind;
	
	Card(int kind, int number){
		this.kind = kind;
		this.number = number;
		
	}
	
	Card(){
		this(SPADE,1);
		
	}
	
	@Override
	public String toString() {
		String kind = "";
		String number = "";
		
		switch(this.kind){
		case 1: 
			kind = "SPADE";
			break;
		
		case 2: 
			kind = "DIAMOND";
			break;
			
		case 3: 
			kind = "HEART";
			break;
		
		case 4: 
			kind = "CLOVER";
			break;
		
		}
		
		//number
		
		switch(this.number){
		case 1: 
			number = "A"; 
			break;
			
		case 11: 
			number = "J";
			break;
			
		case 12: 
			number = "Q";
			break;
		
		case 13: 
			number = "K";
			break;	
		
		default:
//			number = this.number+"";
			number += this.number;
			break;
		
			
		
		
		}
		return "Card [kind = " + kind + ", number = " + number +"]";
	}

	
	
}
	
	
	
