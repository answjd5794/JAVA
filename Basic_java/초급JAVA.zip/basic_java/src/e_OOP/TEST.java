package e_OOP;

public class TEST {
	public static void main(String[] args) {
		int a = 5;
		int b = 9;
		int result = (int)((a/b*100)*100f);
		System.out.println(result);
	}
}
