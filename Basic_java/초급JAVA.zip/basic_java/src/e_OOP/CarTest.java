package e_OOP;

public class CarTest {
	public static void main(String[] args) {
	Car c1 = new Car();
//	c1.color = "black";
//	c1.gearType = "stick";
//	c1.door = 4;
	System.out.println(c1.color);
	System.out.println(c1.gearType);
	System.out.println(c1.door);
	
	Car c2 = new Car("black","Auto",4);
//	Car c3 = new Car("blue",c1.gearType, c1.doo);
	
	System.out.println(c1.color);
	System.out.println(c1.gearType);
	System.out.println(c1.door);
	}
}

class Car{
	String color;
	String gearType;
	int door;
	
	//메서드는 항상 변수 뒤에
	
	Car(){
		color = "black";
		gearType = "stick";
		door = 4;
		
	}
	
	Car(String color, String gearType, int door){
		//다른건 다 기본으로 해주고 -> 기본생성자
		
		this.color = color;
		this.gearType = gearType;
		this.door = door;
	}
	Car(String color){
		this();
		//나머지는 기본옵션
		//생성자 명칭쓰면 안됨
		//생성자의 첫줄에만 들어감
		this.color = color;
	}
}
