package e_OOP;

public class TvTest {
	public static void main(String[] args) {//중괄호가 열렸으니 call stack
		System.out.println(Tv.color);//System이라는 class에서 불러오는것
		//그냥 color만 불러오면 찾을 수 없음
		//Tv.<<- class 이름
		//세모가 비어있으면 변수 , 채워져 있으면 메소드, 삼각형 s는  static이 붙었다는 뜻
		//전역변수는 선언하면 기본값을 붙여주지만 지역변수는 선언과 초기화를 하지 않으면 사용하지 못한다.
		Tv.color = "black"; //검정색으로 초기화
		System.out.println(Tv.color);
		Tv.changeColor();//노랑색으로 변경되어있던 값을 불러오는 것
		System.out.println(Tv.color);
		
		//인스턴스화
		Tv t = new Tv(); 
		//new Tv()-> 인스턴스변수 생성
		//참조형 변수 대입연산자 왼쪽부터
		//주소를 new Tv();에서 찾아와서 t라는 변수에 저장해줌
		//내가 만드는 변수와 인스턴스의 타입은 항상 같아야한다. 
		//ex) c (가져오는 인스턴스 타입과 일치해야한다.) = new 컴퓨터;
		System.out.println(t.channel);
		//t에 있는 주소의 값 heap의 0을 출력하여라
		//값을 지정을 안하면 컴파일러가 기본값 0으로 초기화시킨다.
		t.channel = 10; //t에 있는 주소의 값 heap의 0을 출력하여라
		System.out.println(t.channel);
		t.channelUp();//메소드 호출 call stack
		System.out.println(t.channel);//tv
		t.volume = 15;//t에 있는 volume을 15로 바꿔라
		t.volumeUp();//메소드 호출 call stack;
		System.out.println(t.volume); 
		//클래스변수 : 클래스 명. 변수명(메소드명)
		//인스턴스 변수: 인스턴스화 생성-> 참조변수명.변수명(또는 메소드명)
	}//main method꺼 종료되면 heap은 사라짐

}//method area 종료

//G.C가 실행하여 heap메모리에 있는 것을 지워줌
class Tv{
	//전역변수(멤버변수)
	//클래스변수
	static String color;
	//인스턴스변수
	int channel;
	int volume;
	//메서드
	//static은 class 친구,class method
	static void changeColor(){
		color = "yellow";
	}
	//인스턴스 메서드
	void channelUp(){
		channel++;
		
	}
	
	void volumeUp(){
		volume++;
		
	}
}