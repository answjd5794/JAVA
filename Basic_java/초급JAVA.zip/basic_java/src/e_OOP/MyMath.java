package e_OOP;

public class MyMath {
	public static void main(String[] args) {
		//12. add1 메서드 호출
		MathTest.add1();
		//13. add2 메서드 호출
		MathTest mt = new MathTest();
		int result2 = mt.add2();
		System.out.println(result2);//돌려주는 값이 있으면 변수에 담아서 출력해야한다.
		//14. add3 메서드 호출
		MathTest.add3(50,100);//void니까 반환값음 없음
		//15. add4 메서드 호출
		mt.add4(50,100);
		int result4 = mt.add4(50, 100);
		System.out.println(result4);
		//16. add5 메서드 호출
		mt.add5(20,100L);
		long result5 = mt.add5(20,100L);
		System.out.println(result5);
		//17. add6 메서드 호출
		long result6 = mt.add6(100L,20,30);
		System.out.println(result6);
		//18. add7 메서드 호출
		String e = mt.add7("이선엽");
		System.out.println(e);
		//문제 3-5 계산기, jvm, 계산기가 무한대로 돌아가게 while
		
	}

}

class MathTest{
	//1. 클래스변수 a를 선언하고 10의 값으로 초기화 하여라.
	static int a = 10;
	//2. 클래스변수 b를 선언하고 20의 값으로 초기화 하여라.
	static int b = 20;
	//3. 인스턴스변수 c를 선언하고 30의 값으로 초기화 하여라.
	int c = 30;
	//4. 인스턴스변수 d를 선언하고 40의 값으로 초기화 하여라.
	int d = 40;
	//5. 클래스메서드 add1, 클래스변수 a,b의 합을 출력하는 메서드
	static void add1(){
		int result = a + b;
		System.out.println(result   );
	}
	//6. 인스턴스메서드 add2, 인스턴스변수 c,d의 합을 반환하는 메서드
	int add2(){
		int result = c + d;
		return result;
	}
	//7. 클래스메서드 add3, 매개변수 : int타입 두 개, 매개변수의 합을 출력하는 메서드
	static int add3(int x, int y){
		int result = x + y;
		System.out.println(result);
		return result;
	}
	//8. 인스턴스메서드 add4, 매개변수 : int타입 두 개, 매개변수의 합을 반환하는 메소드
	int add4(int x, int y){
		int result = x + y;
		return result;
	}
	//9. 인스턴스메서드  add5  매개변수 : int타입 하나, long 타입 하나 매개변수의 합을 반환하는 메소드
	long add5(int x, long y){
		long result = x + y; //int -> long 형변환
		return result;
	}
	//10. 인스턴스메서드 add6 매개변수 : int 타입 하나, long타입 두개 매개변수의 합을 반환하는 메소드
	long add6(long y, int z,int a){
		long result = y + z + a;
		return result;
	}
	//11. 인스턴스메서드 add7, 매개변수 문자열 하나, 매개변수에 48~94 중 임의의 값과 문자열의 합을 반환하는 메서드
	String add7(String x){
		int random= (int)(Math.random()*47+48);
		String result = x + random;
		return result;
	}
	
	
}