package e_OOP;

public class Ex3_8 {
	public static void main(String[] args) {
		ExTest01 et1 = new ExTest01();
		ExTest02 et2 = new ExTest02(3);
		//하나를 가지고 있으니까 컴파일러가 기본생성자를 만들어주지 않는다.
		//그래서 int value값을 하나 넣어줘야한다.
	}
}

class ExTest01{
	int value;
	//컴파일러가 기본생성자를 만들어준다.
//	ExTest01(){
//		
//	}
}

class ExTest02{
	int value;
	//컴파일러가 기본생성자를 만들어주지 않는다. 그래서 못찾음
	ExTest02(int value){
		this.value = value;
		
	}
	
}