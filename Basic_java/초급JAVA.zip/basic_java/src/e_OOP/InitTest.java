package e_OOP;

public class InitTest {
	public static void main(String[] args) {
		Init it = new Init(100);
		//1. 기본값 - 명시적초기화
		// action = 100;
		System.out.println(it.action);//명시적초기화 -> 초기화블럭
		
		System.out.println(it.action2);//명시적 초기화 -> 초기화블럭 -> 생성자
		//0 -> 30
		//무조검 생성자는 마지막
	}
}

class Init{
	static int action =100; //1.명시적초기화
	int action2;//명시적초기화 x
	
	Init(int action2){
		this.action2 = action2;
		//인자값을 넣어줌 action2 =0  에서 30으로 넘어간다
	}
	
	
	static {
		action = 10; 
		//
	}
	
	{
		
//		 action2
	}
	
	
	
}