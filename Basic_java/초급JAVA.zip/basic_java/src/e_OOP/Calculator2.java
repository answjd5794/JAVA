package e_OOP;
import java.util.Scanner;

public class Calculator2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
			
		Calc2 c2 = new Calc2();
		System.out.println("숫자를 입력하세요");
		Float firstNum = scanner.nextFloat();
			while(true){
				System.out.println("사칙연산을 입력하세요");
				String buho = scanner.next();
				System.out.println("다음 숫자를 입력하세요");
				float secondNum = scanner.nextFloat();

				if(buho.equals("+")){
					float add = c2.add(firstNum, secondNum);
					System.out.println(add);
					firstNum = add;
						
				}else if(buho.equals("-")){
					float sub = c2.substract(firstNum, secondNum);
					firstNum = sub;
					System.out.println(sub);
						
				}else if(buho.equals("*")){
					float mul = c2.multiply(firstNum, secondNum);	
					firstNum = mul;
					System.out.println(mul);
					
				}else if(buho.equals("/")){
					float div =  c2.divide(firstNum, secondNum);
					firstNum = div;
					System.out.println(div);
					
					
				}else{
					System.out.println("연산 종료.");
				}
					
			    
			  }
			}
}
class Calc2 {
	//1. 두 개의 int타입 입력받아 두 인자의 합의 결과를  반환하는 인스턴스메서드 
	//  add를 구현 하여라.
	float add(float a, float b){
		float result = a + b;
		return result;
	}
	
	
	//2. 두 개의 int타입 입력받아 앞의 인자에서 뒤의 인자를 뺀 결과를 반환하는 
	//   인스턴스메서드 substract를 구현 하여라.
	float substract(float a, float b){
		float result = a - b;
		return result;
	}
	
	
	//3. 두 개의 int타입 입력받아 두 인자의 곱의 결과를 반환하는 인스턴스메서드
	//   multiply를 구현 하여라.
	//   단. overflow를 고려하여라.
	float multiply(float a, float b){
		float result = a * b;
		return result;
	}
	
	
	//4. 두 개의 int타입 입력받아 앞의 인자를 뒤의 인자로 나누기한 결과를 반환하는
	//   인스턴스메서드 divide를 구현 하여라.
	//   단. 결과는 소수점 두 번째 자리에서 반올림하여 첫 번째 자리까지 표현 하여라.
	float divide(float a, float b){
		float result = (int)((a/b*10+0.5)/10F);
		return result;
	}
	
}