package e_OOP;

public class Qu3_8 {
		  public static void main(String[] args) {
		    //7. 3번의 add메서드를 호출하여라.  	
			 int result=  MyAdd.add(10);
			 System.out.println(result);
		    //8. 4번의 add메서드를 호출하여라.
			  MyAdd ma = new MyAdd();
			  int result2 = ma.add(10,11);
			  System.out.println(result2);
		    //9. 5번의 add메서드를 호출하여라.
			 long result3 = ma.add(10, 11L);
			 System.out.println(result3);
		    //10. 6번의 add메서드를 호출하여라.
			float result4 =  ma.add('a', 100f);
			System.out.println(result4);
		  }
		}
		class MyAdd {
		  //1. 클래스변수 a를 선언하고 20의 값으로 초기화 하여라.
			static int a = 20;
		  //2. 인스턴스변수 b를 선언하고 15의 값으로 초기화 하여라.
			int b = 15;
		  //3. int타입의 매개변수가 하나이며 변수 a의 합을 반환하는 클래스메서드를 add를 작성 
		  //  하여라.
			static int add(int x){
				int result = a + x; 
				return result;
			}


		  //4. int타입의 매개변수가 두개이고 매개변수의 합을 반환하는 인스턴스메서드를 add를 
		  //  작성 하여라.
			int add(int a, int b){
				int result = a + b; 
				return result;
			}
		  //5. int타입, long타입 각 한 개의 매개변수, 매개변수의 합을 반환하는 인스턴스
		  //   메서드 add를 작성 하여라.
			long add(int a, long b){
				long result = a + b;
				return result;
			}

		  //6 char타입, float타입 각 한 개의 매개변수, 매개변수의 합을 반환하는 인스턴스
		  //   메서드 add를 작성 하여라.
			float add(char a, float b){
				float result = a + b;
				return result;
			}
		 //추가 1. 인스턴스 메서드 add, 매개변수는 long타입 하나와 int 타입 하나이며 
		 //매개변수의 합을 반환하는 메서드
		long add(long a, int b){
				long result = a + b; 
				return result;
			}
		//추가2. 인스턴스 메서드 add, 매개변수가  int 타입 두개이며 두개의 합을 반환하는 메서드
		// 단, 반환타입이 long 타입이어야 한다.	
//		long add(int x, int y){
//			long result = x + y;
//			return result;
//		} 같은 메서드랑 취급을 한다.
}