package e_OOP;

public class DiceTest {
	public static void main(String[] args) {
		//호출할 때
		//1. 누구 친구인지 확인해라
		//2. 인스턴스 메서드 일 때 -> 인스턴스 화
		
		  DoubleDice dd = new DoubleDice();
		//참조변수명.인스턴스 메서드명 ();
		  int result = dd.throwDice();
		  //return 값을 f2누르면 확인 할 수 있음.
		  //int 타입의 결과를 돌려주니까  int 변수에 넣어준다.
		 System.out.println("이동해야할 거리는:" + result);
		
		
	}
}

class DoubleDice{
	// 인스턴스 메서드명 : throwDice
	// 주사위 두개를 던진다.
	// 던진 주사위 두 개의 합을 반환한다.
	// 단, 주사위의 눈이 같은게 나왔을 때는 한번 더 던져준다. 
	//재귀 호출을 이용해서 만들어라.
	//다 만들고 jvm을 그렸을 때 주사위 눈은 같은거 한번 , 다른거 한번으로 해서 이동거리가 나오도록 하면됨
	//ex) 3,2 -> 5 3,3 -> 2,2 -> 20
	
	int throwDice(){
		int firstDice = (int)(Math.random()*6+1);
		int secondDice = (int)(Math.random()*6+1);
		System.out.println("주사위 두 값 : " + firstDice+","+secondDice);
		int result = firstDice+secondDice;
		if(firstDice == secondDice){
			//한번더
			result += throwDice();//나중에 던진거 까지 합쳐서 출력해준다.
			System.out.println("같은 번호는 한번 더");
		}
		return result;
		
	}
	
}