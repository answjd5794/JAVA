package project;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import sun.org.mozilla.javascript.internal.ast.SwitchCase;

//프로그램을 실행하게 만드는 클래스
public class ViewClass {
	private IService service = new IServiceImpl();
	
	public void startMethod(){
		System.out.println("어서오세요.");
		System.out.println("고르세요");
		System.out.println("1.회원 가입");
		System.out.println("2.로그인");
		System.out.println("3.끝내기");
		
		//고르기
		Scanner sc = new Scanner(System.in);
		int input  = sc.nextInt();
		
		//각각의 메서드로 이동
		switch (input) {
		case 1:
			//회원가입
			createMember();
			break;
		
		case 2:
			//로그인
			logIn();
			break;
		
		case 3:
			//끝내기
			break;


		default:
			System.out.println("뭐하냐 임마");
			break;
		}
	
	}

	private void logIn() {
		//id, pw
		Scanner sc = new Scanner(System.in);
		System.out.println("아이디를 입력해주세요");
		String mem_id = sc.next();
		System.out.println("비밀번호를 입력해주세요");
		String mem_pass = sc.next();
		
		//인터페이스 구현 <MAP>이용해서 다형성 이용
		Map<String, String> params = new HashMap<>();
		params.put("mem_id",mem_id);
		params.put("mem_pass",mem_pass);
		
		String login_id = service.logIn(params);
		
		if (login_id == null) {
			System.out.println("그런사람 없다.");
		}else{
			System.out.println(login_id + "어서 옵쇼");
			showMemList();
		}
	}

	private void showMemList() {

	}	
	
	//회원 가입
	private void createMember() {
//		MEM_ID
//		MEM_PASS
//		MEM_NAME
//		MEM_REGNO1
//		MEM_REGNO2
//		MEM_ZIP
//		MEM_ADD1
//		MEM_ADD2
//		MEM_HOMETEL
//		MEM_COMTEL
//		MEM_MAIL
		
		Scanner sc = new Scanner(System.in);
			System.out.println("아이디를 입력해주세요");
			String mem_id = sc.next();
			System.out.println("비밀번호를 입력해주세요");
			String mem_pass = sc.next();
			System.out.println("이름을 입력해주세요");
			String mem_name = sc.next();
			System.out.println("주민번호 앞자리를 입력해주세요");
			String mem_regno1 = sc.next();
			System.out.println("주민번호 뒷자리를 입력해주세요");
			String mem_regno2 = sc.next();
			System.out.println("주소를 입력해주세요");
			String mem_add1 = sc.next();
			System.out.println("상세주소를 입력해주세요");
			String mem_add2 = sc.next();
			System.out.println("집 전화번호를 입력해주세요");
			String mem_hometel = sc.next();
			System.out.println("회사번호를 입력해주세요");
			String mem_comtel = sc.next();
			System.out.println("이메일을 입력해주세요");
			String mem_mail = sc.next();
		
			
			Map<String, String> params2 = new HashMap<>();
			params2.put("mem_id", mem_id);
			params2.put("mem_pass", mem_pass);
			params2.put("mem_name", mem_name);
			params2.put("mem_regno1", mem_regno1);
			params2.put("mem_regno2", mem_regno2);
			params2.put("mem_add1", mem_add1);
			params2.put("mem_add2", mem_add2);
			params2.put("mem_hometel", mem_hometel);
			params2.put("mem_comtel", mem_comtel);
			params2.put("mem_mail", mem_mail);
			
			
		
	}
	
	
}
