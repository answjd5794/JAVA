package project;

import java.util.Map;

public interface  IDao {


	
}
