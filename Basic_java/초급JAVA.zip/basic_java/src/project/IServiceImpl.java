package project;

import java.util.Map;

public class IServiceImpl implements IService {

	private IDao dao = new IDaoImpl();
	

	
	
}
