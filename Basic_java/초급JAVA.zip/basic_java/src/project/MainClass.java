package project;

public class MainClass {
	public static void main(String[] args) {
		ViewClass vc = new ViewClass();
		vc.startMethod();
		
		
		
		
		//구조
		
		//1. 회원가입 -> 하러가고
		
		//2. 로그인-> 회원리스트 나옴-> 한명 고르고-> 그 사람의 상세 내역 조회 -> 수정or삭제
		
		//3. 종료
	}
}
