package g_exception;

import java.sql.SQLException;

public class Exception_04 {
	public static void main(String[] args) {
		
		Controller.idCheck();
		
	}
}

class Controller{
	static void idCheck(){ 
	Service.idCheck();
	
	}
}
class Service{
	static void idCheck(){
		try {
			DAO.idCheck();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

class DAO{
	static void idCheck() throws SQLException {
//		throws는 던지기  SQLException을 통해서 Service에 try/catch를 넘겨줌.
		SQLException sq = new SQLException("ORA_0001 : unique constrant");
		throw sq;//예외 발생
		
	}
}