package g_exception;

import com.sun.org.apache.xpath.internal.operations.Equals;

public class StringEx {
	public static void main(String[] args) {
		//String(String s)
		//주어진 문자열 s를 갖는 String 인스턴스를 생성한다
		String s = new String("Hello");
		
		//char charAt(int index)
		//지정된 위치에(index)에 있는 문자열을 알려준다.
		String s2 = "Hello";
		char c = s.charAt(1);
		System.out.println(c);
		
		//int compareTo(Stirng str)
		//문자열과 사전 순서 비교, 같으면 0, 이전이면 음수, 이후면 양수
		//뒷줄은 상관없이 앞 글자만 따서 확인하는 것.
		int i = "aaa".compareTo("aaa");
		int i2 = "aaa".compareTo("aab");
		System.out.println(i);
		System.out.println(i2);
		
		//String concat(String str);
		//문자열 (str)을 뒤에 덧붙임.
		String s3 = "hello";
		String s4 = s.concat(" Oracle");
		System.out.println(s4);
		
		//boolean constains(CharSequence s)
		//지정된 문자열이 포함되었는지 검사해서 들어있으면 true, 없으면 false
		String s5 = "JavaSoEz";
		boolean b = s5.contains("S");
		System.out.println(b);
		
		//boolean endsWith(String suffix)
		//지정된 문자열로 끝나는지 검사한다.
		String s6 = "JavaSoEzjava";
		boolean b2 = s6.endsWith("java");
		System.out.println(b2);
		
		//boolean equals(Object obj)
		//매개변수로 받은 obj가 String 인스턴스의 문자열로 비교함.
		//obj가 String과 같은 문자열이 아니거나 String이 아니면 false를 반환한다.
		String s7 = "java";
		boolean b3 = s7.equals("java");
		System.out.println(b3);
		
		//int indexOf(int ch)
		//주어진 문자가 문자열에 존재하는지 확인해서 위치(index)를 알려준다.
		//못찾으면 -1을 반환한다.
		String s8 = "Hello";
		int b4 = s8.indexOf('l');
		System.out.println(b4);

		//int lastIndexOf(int ch)
		//지정된 문자열을 인스턴스의 문자열 끝에서 부터 못찾으면 위치(index)를 알려줌.
		//못찾으면 -1을 반환함.
		String s9 = "Moon";
		int b5 = s9.lastIndexOf('n');
		System.out.println(b5);
		
		//int length()
		//문자열의 길이 length()를 알려준다.
		String s10 = "Moon"; 
		int b6 = s10.length();
		System.out.println("length의 길이:" + b6);
		
		//String replace(Char Sequence old, CharSequence nw)
		//문자열 중 문자열 old를 새로운 문자열 nw로 모두 바꾼 문자열을 반환한다.
		String s11 = "Moon";
		String b7 = s11.replace("Oracle", "Java");
		System.out.println(b7);
		
		
		//String substring(int begin, int end)
		String a = "I wanT go home";
		String d =a.substring(2,5);
		System.out.println(d);
		
		//String toLowerCase();
		//String 인스턴스에 저장되어있는 모든 문자열을 소문자로 변환
		String f = a.toLowerCase();
		System.out.println(f);
		
		//pperCase()
		//String 인스턴스에 저장된 문자열을 대문자로 변환
		String g = a.toUpperCase();
		System.out.println(g);
		
		//String trim()
		//문자열의 왼쪽 끝과 오른쪽 끝에 있는 공백을 없앤 결과를 반환한다.
		//이때, 문자열 중간에 있는 공백은 제거되지 않는다.
		String trim = "     My				trim";
		String trimReturn = trim.trim();
		System.out.println(trim);
		
		//static String valueOf(boolean b)
		//지정된 값을 문자열로 변환하여 반환
		//참조변수의 경우 toString()을 호출한 결과를 반환(매개변수로 모든 타입가능)
		String v1 = String.valueOf(2);
		String v2 = String.valueOf("aaa");
		String v3 = String.valueOf(100);
		String v4 = String.valueOf(true);
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(v3);
		System.out.println(v4);
		
		
		
		
	}
}
