package g_exception;

public class Exception_05 {
	public static void main(String[] args) {
//		copyfiles();
//		install();
//		deletefiles();
		
		try {
			copyfiles();
			install();
		} catch (Exception e) {
			deletefiles();
			e.printStackTrace();
		} finally{
			deletefiles();
		}
		
	}
	
	static void copyfiles(){
		
		
	}
	
	static void install(){
		
		
	}
	
	static void deletefiles(){
		
		
	}
	
		
	
	
}
