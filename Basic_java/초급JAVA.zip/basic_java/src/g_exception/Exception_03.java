package g_exception;

public class Exception_03 {
	public static void main(String[] args) {
		//예외 발생시키는 법
		//Exception e1 = new Exception(); 만 하면 발생했을 때의 이유를 안넣어서 출력이 안됨
		//이유 문구를 만들기 위해서 new Exception("상헌아 지각하지마.");< 이렇게 바꿔서 이유를 넣어줄 수 있음.
		Exception e1 = new Exception("내 핸드폰 ㅜㅜ");
		
		try {
			throw e1;
		} catch (Exception e) {
			System.out.println("예외 발생시키기 성공!!");
			//예외가 발생했을 때의 실제 발생한 문구를 출력해주는 용도 e.printStackTrace();
			//실제 발생한건 아님!!!
			e.printStackTrace();
			//이유만 뽑아옴 e.getMessage()
			System.out.println(e.getMessage());
		}
		
		RuntimeException re = new RuntimeException("내 핸드폰 액정 언제갈아");
//		throw re;//예외 발생 근데 에러가 안나서 try catch가 안뜸	
//		System.out.println("dff"); 에러남
		try{
			throw re;
		} catch (RuntimeException e){
			e.printStackTrace();
		}
		
		/*
		컴파일러가 예외처리를 강제하지 않는 경우
			- RuntimeException과 그 자손들 : 프로그래머가 잘못한거니까 니가 알아서 처리해
			- 에러는 어짜피 못고치니까 강제할 필요가 없음
			
			이 두가지를 확인하지 않는 에러라고 'unChecked 예외' 라고 한다.
		
		 */
	}
}
